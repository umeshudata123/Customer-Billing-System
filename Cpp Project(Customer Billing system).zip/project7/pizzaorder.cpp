#include "includefiles.h"

#include "RawProduct.cpp"
#include "MenuSideProduct.cpp"

#include "MenuPizzaProduct.cpp"



class pizzaorder : public Pizza , public discount
{
    private:
            string cashieruname;

    public:

            float prize=0;
            int OrderChoice;

            int orderswitch(string cashieruname)
            {
                OrderChoice=orderchoice(cashieruname);
                switch(OrderChoice)
                    {
                    case 1:
                        takeorder(cashieruname);
                        system("cls");
                        orderswitch(cashieruname);
                        break;
                    case 2:
                        //deleteorder();
                        system("cls");
                        orderswitch(cashieruname);
                        break;
                    case 3:
                        return 0;
                    default:
                            system("cls");
                            cout<<" **Wrong Choice\n";
                            orderswitch(cashieruname);
                }

            }

            int takeorder(string cashieruname)
            {
            OrderChoice=takeorderchoice();
            MenuPizza m;
            switch(OrderChoice)
                {
                case 1:
                    prize=m.takeorderpizza();
                    takeorder( cashieruname);
                    break;
                case 2:
                    prize=m.takeorderproduct();
                    takeorder( cashieruname);
                    break;
                case 3:
                    m.getpizzaproductswitch();
                    system("cls");
                    //orderswitch();
                    break;
                case 4:
                        pizzaprice=m.takeprintbill(cashieruname);
                        cin>>pizzaprice;
                        break;
                case 5:
                        return 0;
                default:
                        system("cls");
                        cout<<" **Wrong Choice\n";
                        takeorder( cashieruname);
                }
            }

            int takeorderchoice()
            {
            cout<<"\n\n\t\t\t------------------------------";
            cout<<"\n\t\t\t         Order Choice System   ";
            cout<<"\n\t\t\t------------------------------";
            cout<<"\n\n\t\t\t What you want to do?\n";
            cout<<"\n\t\t\t1.\t Pizza Order \n\t\t\t2.\t Delete Order \n\t\t\t3.\t Print Bill. \n";
            cout<<"\n\nEnter Your Option: ";
            cin >> OrderChoice;

            while(!cin.good())
            {
                cout<<"**Please Enter Number Values Only \n";
                cin.clear();
                cin.ignore(2000000,'\n');
                cout<<"\n\n\t\t\t------------------------------";
                cout<<"\n\t\t\t         Order Choice System   ";
                cout<<"\n\t\t\t------------------------------";
                cout<<"\n\n\t\t\t What you want to do?\n";
                cout<<"\n\t\t\t1.\t Pizza Order \n\t\t\t2.\t Delete Order \n\t\t\t3.\t Print Bill. \n";
                cout<<"\n\nEnter Your Option: ";
                cin >> OrderChoice;
            }
            return OrderChoice;
}

            int orderchoice(string cashieruname)
            {
                cout<<"\n\n\t\t\t------------------------------";
                cout<<"\n\t\t\t         Order System   ";
                cout<<"\n\t\t\t------------------------------";
                cout<<"\n\t\t\tCashier User Name:"<<cashieruname;
                cout<<"\n\n\t\t\t What you want to do?\n";
                cout<<"\n\t\t\t1.\t Take Order \n\t\t\t2.\t Delete Order \n\t\t\t3.\t Log Out \n";
                cout<<"\n\nEnter Your Option: ";
                cin >> OrderChoice;

                while(!cin.good())
                {
                    cout<<"**Please Enter Number Values Only \n";
                    cin.clear();
                    cin.ignore(2000000,'\n');
                    cout<<"\n\n\t\t\t------------------------------";
                    cout<<"\n\t\t\t         Owner Main System   ";
                    cout<<"\n\t\t\t------------------------------";
                    cout<<"\n\n\t\t\t What you want to do?\n";
                    cout<<"\n\t\t\t1.\t Take Order \n\t\t\t2.\t Delete Order \n\t\t\t3.\t Log Out \n";
                    cout<<"\n\nEnter Your Roll Option: ";
                    cin >> OrderChoice;
                }
                return OrderChoice;
            }

};

