#include "loginone.h"

loginone::loginone()
{
    //ctor
}

loginone::~loginone()
{
    //dtor
}
