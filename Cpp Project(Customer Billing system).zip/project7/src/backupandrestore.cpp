#include "backupandrestore.h"

backupandrestore::backupandrestore()
{

}

backupandrestore::~backupandrestore()
{
    //dtor
}
