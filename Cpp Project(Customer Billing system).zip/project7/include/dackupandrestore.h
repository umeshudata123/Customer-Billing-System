#ifndef DACKUPANDRESTORE_H
#define DACKUPANDRESTORE_H


class dackupandrestore
{
    public:
        dackupandrestore();
        virtual ~dackupandrestore();

    protected:

    private:
};

#endif // DACKUPANDRESTORE_H
