#ifndef LOGINONE_H
#define LOGINONE_H


class loginone
{
    public:
        loginone();
        virtual ~loginone();

    protected:

    private:
};

#endif // LOGINONE_H
