#ifndef INCLUDEFILES_H
#define INCLUDEFILES_H

#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <cctype>
#include <fstream>
#include <string.h>
#include <process.h>
#include <bits/stdc++.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <ctime>
#include <dirent.h>
#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <string>


using namespace std;

class includefiles
{
    public:
        includefiles();
        virtual ~includefiles();

    protected:

    private:
};

#endif // INCLUDEFILES_H
