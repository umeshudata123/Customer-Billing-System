#ifndef GOODS_H
#define GOODS_H

class goods
{
    public:

        goods();
        virtual ~goods();
        goods(const goods& other);
        goods& operator=(const goods& other);

    protected:

    private:
};

#endif // GOODS_H
