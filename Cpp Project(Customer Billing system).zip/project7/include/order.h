#ifndef ORDER_H
#define ORDER_H

class order
{
    public:

    protected:

    private:


};

#endif // ORDER_H
