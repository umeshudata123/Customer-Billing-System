#include "includefiles.h"
#include "backupandrestore.h"

class Pizza
{
    private:
            char pizzaname[15],pizzadescription[61];
            char pizzasize[20];
            char pizzatype[20];
            string line;
            string pizzaproducttype;

            int quantitypizza;
            int sizeofpizza;



    public:
            int pizzaid1=0;
            int pizzaadd;
            float pizzaprice;

            string path="C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\menupizzaproduct.dat";
            string path1="C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\pizzacount.dat";

            string pizzaproducttype1="Veg";
            string pizzaproducttype2="Non-Veg";

            int count,sizechchoice,length_pizzadescription,pizzatypechoice;


            int getpizzaid()
            {
                return pizzaid1;
            }
            float getprice()
            {
                return pizzaprice;
            }

            char *getpizza()
            {
                    return pizzaname;
            }

            string getpizzatype()
            {
                return pizzaproducttype;
            }

            char alpha(char pizzaname)
            {
               if(isalpha(pizzaname))
                {
                    return pizzaname;
                }
                else{
                      cout<<" **Enter Char Only\n";
                      return 0;
                   }
            }

    public:
            int sizeofpizzachoice()
            {
                        cout<<"\n\n\t\t\t What you want to do?\n";
                        cout<<"\n\t\t\t1.\t Small \n\t\t\t2.\t Regular \n\t\t\t3.\t Medium \n\t\t\t4.\t Large \n";
                        cout<<"\n\nEnter your option: ";
                        cin >> sizechchoice;
                         while(!cin.good())
                           {
                               system("cls");
                               cout<<"**Please enter number values only \n";
                               cin.clear();
                               cin.ignore(2000000,'\n');

                                    cout<<"\n\n\t\t\t What you want to do?\n";
                                    cout<<"\n\t\t\t1.\t Small \n\t\t\t2.\t Regular \n\t\t\t3.\t Medium \n\t\t\t4.\t Large \n";
                                    cout<<"\n\nEnter your option: ";
                               cin >> sizechchoice;
                           }
                        return sizechchoice;
            }

            int vegnonvegchoice()
            {
                        cout<<"\n\n\t\t\t What you want to do?\n";
                        cout<<"\n\t\t\t1.\t Veg \n\t\t\t2.\t NonVeg \n";
                        cout<<"\n\nEnter your option: ";
                        cin >> pizzatypechoice;
                         while(!cin.good())
                           {
                               system("cls");
                               cout<<"**Please enter number values only \n";
                               cin.clear();
                               cin.ignore(2000000,'\n');

                                    cout<<"\n\n\t\t\t What you want to do?\n";
                                    cout<<"\n\t\t\t1.\t Veg \n\t\t\t2.\t NonVeg \n";
                                    cout<<"\n\nEnter your option: ";
                                    cin >> pizzatypechoice;
                           }
                       switch(pizzatypechoice)
                       {
                       case 1:
                            pizzaproducttype=pizzaproducttype1;
                            break;
                       case 2:
                            pizzaproducttype=pizzaproducttype2;
                            break;
                       default:
                            system("cls");
                            cout<<"**Wrong Choice";
                            vegnonvegchoice();
                       }
                       return 0;
            }

            //METHOD FOR ADD PIZZA PRODUCT DETAILS
            void addpizzaproduct()
            {
               /* ifstream pizzaidin;
                pizzaidin.open(path1);
                getline(pizzaidin, line);
                stringstream pizzain(line);
                pizzain>>pizzaid1;
                */

                pizzaid1++;

                a:
                    cout<<"\n Enter Pizza Name:";
                    cin>>pizzaname;
                     if(alpha(*pizzaname)!=0)
                       {
                           goto b;
                       }

                       else
                        {
                          goto a;
                        }
                b:
                    cout<<"\n Enter Pizza Description:";
                    cin>>pizzadescription;
                    length_pizzadescription=strlen(pizzadescription);
                    if(length_pizzadescription>=5 && length_pizzadescription<=60)
                    {
                        goto c;
                    }
                    else
                    {
                        cout<<"\n **Enter Address valid (Minimum 20 characters) only";
                        goto b;
                    }
                c:
                   cout<<"\n Enter Pizza size";
                   cin>>pizzasize;
                   cout<<"\n enter pizza type";
                   cin>>pizzatype;
                   cout<<"\n Enter pizza price";
                   cin>>pizzaprice;

                    /*ofstream pizzaidout;
                    pizzaidout.open(path1.c_str());
                    pizzaidout<<pizzaid1;
                    pizzaidout.close();*/
            }

            //METHOD FOR VIEW DETAILS OF PIIZA PRODUCT
            void viewpizzaproduct(int count)
            {
                cout<<"\n "<<pizzaid1<<"\t"<<pizzaname<<"\t\t"<<pizzadescription<<"\t\t\t"<<pizzasize<<"\t\t"<<pizzatype<<"\t\t"<<pizzaprice<<"\n";
            }
};//END OF CLASS

class MenuPizza : protected Pizza
{
    public:
            int pizzaitemnumber,pizzaswitchchoice;
            int flag=0;

            string takeproduct;

            char searchpizzaname[15];
            string searchpizzaproducttype;
            int pizzaproducttype;

            //METHOD FOR SAVE PIZZA PRODUCT DETAILS INTO FILE
            void AddPizzaProduct()
            {
                system("cls");
                Pizza pi;
                cout<<"\n How Many Products Want To Enter:";
                while(!(cin >> pizzaitemnumber))
                {
                    cout<<" **Enter Numbers Only\n";
                    cin.clear();
                    cin.ignore(2000000,'\n');
                    cout<<"\n How Many Pizza Products Want To Enter:";
                }

                fstream file;
                file.open(path,ios::binary | ios::out |ios::in| ios::app);
                if(!file.is_open())
                {
                    cout<<"\n error";
                }
                else
                {
                    for(pizzaswitchchoice=1;pizzaswitchchoice<=pizzaitemnumber;pizzaswitchchoice++)
                    {
                            pi.addpizzaproduct();
                            file.write((char *)&pi,sizeof(Pizza));
                    }
                }
                 file.close();
                 getpizzaproductswitch();
            }
    public:
            //METHOD FOR DISPLAYING PIZZA PRODUCT DETAILS FROM FILE
            void ViewPizzaProduct()
            {
                system("cls");
                count=0;
                Pizza pi;
                ifstream file;

                file.open("C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\menupizzaproduct.dat",ios::binary | ios::out);
                if(!file.is_open())
                    {
                        cout<<"**error\n";
                    }
                else
                    {
                        cout<<"\n No\tPizza Name\tPizza Decription\tPizza Size\tPizza Type\tPizza Price";
                        file.read((char *)&pi,sizeof(Pizza));
                        while(!file.eof())
                            {
                                flag=1;
                                count++;
                                pi.viewpizzaproduct(count);
                                file.read((char *)&pi,sizeof(Pizza));
                            }
                    }
                file.close();
               // TakeProduct();
            }

            float TakeProduct()
            {

                point:
                    flag=0;
                    Pizza pi;
                    count=0;
                    cout<<"\n Whice Pizza Want To Add:";
                    cin>>pizzaadd;

                    fstream file(path,ios::binary | ios::out|ios::in| ios::app);
                        if(!file.is_open())
                            {
                                cout<<"\n **Error: Unable to open file...\n";
                            }
                            else
                                {
                                    while(file.read((char *)&pi,sizeof(Pizza)))
                                        {
                                            if(pizzaadd==pi.getpizzaid())
                                                {
                                                    flag=1;
                                                    pizzaprice=pizzaprice+pi.getprice();
                                                }
                                        }
                                }
                                if(flag==0)
                                    {
                                        system("cls");
                                        cout<<"\n**No Record Found";
                                        return 0;
                                    }
                           file.close();
                           cout<<pizzaprice;
                           //show(pizzaprice);
                           return pizzaprice ;
            }

            float show(float pizzaprice)
            {
                cout<<"PP;";
                return pizzaprice;
            }

    private:
            //METHOD FOR SEARCH PARTICULAR PIZZA PRODUCT BY THE PIZZA NAME
            void SearchPizzaProduct()
            {
                    flag=0;
                    system("cls");
                    Pizza pi;
                    count=0;
                    cout<<"\n Enter Name of Pizza Product Want To Search:";
                    cin>>searchpizzaname;

                    fstream file(path,ios::binary | ios::out|ios::in| ios::app);
                        if(!file.is_open())
                            {
                                cout<<"\n **Error: Unable to open file...\n";
                            }
                            else
                                {   cout<<"\n No\tPizza Name\tPizza Decription\tPizza Size\tPizza Type\tPizza Price";
                                    while(file.read((char *)&pi,sizeof(Pizza)))
                                        {
                                            if(strcmp(searchpizzaname,pi.getpizza())==0)
                                                {
                                                    flag=1;
                                                    pi.viewpizzaproduct(count);
                                                }
                                        }
                                }
                                if(flag==0)
                                    {
                                        system("cls");
                                        cout<<"\n**No Record Found";
                                    }
                           file.close();
                           getpizzaproductswitch();
            }

            //METHOD FOR DELETE THE PIZZA PRODUCT BY TH PIZZA NAME
            void DeletePizzaProduct()
            {
                ifstream filein;
                ofstream fileout;
                system("cls");
                Pizza pi;
                flag=0;

                 cout<<"\n\n\n\tDelete Record";
                 cout<<"\n\nEnter Name of Pizza Product Want to Delete  :  ";
                 cin>>searchpizzaname;

                 filein.open("C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\menupizzaproduct.dat",ios::binary | ios::in);
              if(!filein)
                  cout<<"File not found";
              else
                {
                   fileout.open("C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\menupizzaproductnew.dat",ios::binary | ios::out);
                   filein.read((char *)&pi, sizeof(Pizza));

              while(!filein.eof())
                  {
                    if(strcmp(searchpizzaname,pi.getpizza()))
                            {
                                flag=1;
                                fileout.write((char *)&pi, sizeof(Pizza));
                            }
                    filein.read((char *)&pi, sizeof(Pizza));
                  }
                            filein.close();
                            fileout.close();

                remove("C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\menupizzaproduct.dat");
                rename("C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\menupizzaproductnew.dat","C:\\Users\\rohan\\Google Drive\\project7\\DataFiles\\Menupizzaproductdatafile\\menupizzaproduct.dat");
                }
              if(flag==0)
                 cout<<"\n\nSorry!!! Record Not Found ";

                getpizzaproductswitch();
        }

            //METHOD FOR UPDATE THE PIZZA PRODUCT BY THE PIZZA NAME
            void UpdatePizzaProduct()
            {
                flag=0;
                system("cls");
                Pizza pi;
                cout<<"Enter Name Of Product That Should Be Searched:";
                cin>>searchpizzaname;

               fstream file(path,ios::binary | ios::out |ios::in);
               if(!file.is_open())
                  {
                     cout<<"Error: Unable to open file....";
                  }
               else
                  {
                     file.read((char *)&pi,sizeof(Pizza));
                     while(!file.eof())
                       {
                          if(strcmp(searchpizzaname,pi.getpizza())==0)
                             {
                                file.seekg(0,ios::cur);
                                cout<<"\nEnter new record ";
                                pi.addpizzaproduct();
                                file.seekp(file.tellg()-sizeof(Pizza));
                                file.write((char *)&pi,sizeof(Pizza));
                                flag=1;
                              }
                            file.read((char *)&pi,sizeof(pi));
                        }
                    }

                if(flag==0)
                      {
                           system("cls");
                           cout<<"\n**No Record Found";
                      }
                       file.close();
                      getpizzaproductswitch();
            }

            //DISPLAY MENU
            int pizzaproduct()
            {
                cout<<"\n\n\t\t\t------------------------------";
                cout<<"\n\t\t\t   Pizza Product System";
                cout<<"\n\t\t\t------------------------------";
                cout<<"\n\n\t\t\t What you want to do?\n";
                cout<<"\n\t\t\t1.\t AddPizzaProduct \n\t\t\t2.\t DeletePizzaProduct \n\t\t\t3.\t SearchPizzaProduct \n\t\t\t4.\t ViewPizzaProduct \n\t\t\t5.\t UpdatePizzaProduct \n\t\t\t6.\t Exit\n";
                cout<<"\n\nEnter your option: ";
                cin >> pizzaswitchchoice;
                 while(!cin.good())
                   {
                       system("cls");
                       cout<<"**Please enter number values only \n";
                       cin.clear();
                       cin.ignore(2000000,'\n');
                            cout<<"\n\n\t\t\t------------------------------";
                            cout<<"\n\t\t\t   Pizza Product System";
                            cout<<"\n\t\t\t------------------------------";
                            cout<<"\n\n\t\t\t What you want to do?\n";
                            cout<<"\n\t\t\t1.\t AddPizzaProduct \n\t\t\t2.\t DeletePizzaProduct \n\t\t\t3.\t SearchPizzaProduct \n\t\t\t4.\t ViewPizzaProduct \n\t\t\t5.\t UpdatePizzaProduct \n\t\t\t6.\tExit\n";
                            cout<<"\n\nEnter your option: ";
                       cin >> pizzaswitchchoice;
                   }
                return pizzaswitchchoice;
            }
    public:
            //SWITCH FUNCTION
            int getpizzaproductswitch()
            {
                pizzaswitchchoice=pizzaproduct();

                switch(pizzaswitchchoice)
                    {
                    case 1:
                        AddPizzaProduct();
                        break;
                    case 2:
                       DeletePizzaProduct();
                        break;
                    case 3:
                        SearchPizzaProduct();
                        break;
                    case 4:
                        ViewPizzaProduct();
                        getpizzaproductswitch();
                        break;
                    case 5:
                        UpdatePizzaProduct();
                        break;

                    case 6:return 0;
                            break;
                    default:
                            system("cls");
                            cout<<"**Wrong Choice";
                            getpizzaproductswitch();
                }
        }
};//END OF CLASS
