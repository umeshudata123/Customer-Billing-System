#include "CashierDetails.cpp"
#include "Admin.cpp"

//#include "CustomerDetails.cpp"

#include "DeliveryBoy.cpp"

//#include "RawProduct.cpp"
//#include "MenuSideProduct.cpp"

//#include "MenuPizzaProduct.cpp"

#include "pizzaorder.cpp"

#include "startup.h"
#include "Furniture.h"
#include "includefiles.h"


using namespace std;
int count,contact_no;
//float price;

//system("color f0");

class Dominoz
{
    int StartUpchoice=0;
    string roll;
    char *p="00";

        int dominozgetownerchoice()
        {
            cout<<"\n\n\t\t\t------------------------------";
            cout<<"\n\t\t\t         Owner Main System   ";
            cout<<"\n\t\t\t------------------------------";
            cout<<"\n\n\t\t\t What you want to do?\n";
            cout<<"\n\t\t\t1.\t Add Owner \n\t\t\t2.\t Manager System\n\t\t\t3.\t Cashier System \n\t\t\t4.\t Delivery Boy System \n\t\t\t5.\t Menu Side Product System \n \t\t\t6.\t Raw Product System \n \t\t\t7.\t Furniture System \n \t\t\t8.\t Log Out \n";
            cout<<"\n\nEnter Your Option: ";
            cin >> StartUpchoice;

            while(!cin.good())
            {
                cout<<"**Please Enter Number Values Only \n";
                cin.clear();
                cin.ignore(2000000,'\n');
                cout<<"\n\n\t\t\t------------------------------";
                cout<<"\n\t\t\t         Owner Main System   ";
                cout<<"\n\t\t\t------------------------------";
                cout<<"\n\n\t\t\t What you want to do?\n";
                cout<<"\n\t\t\t1.\t Add Owner \n\t\t\t2.\t Manager System\n\t\t\t3.\t Cashier System \n\t\t\t4.\t Delivery Boy System \n\t\t\t5.\t Menu Side Product System \n \t\t\t6.\t Raw Product System \n \t\t\t7.\t Furniture System \n \t\t\t8.\t Log Out \n";
                cout<<"\n\nEnter Your Roll Option: ";
                cin >> StartUpchoice;
            }
            return StartUpchoice;
        }

        int dominozownerswitch()
        {
            StartUpchoice=dominozgetownerchoice();
            ManagerDetails m;
            DeliveryBoy1 d;
            CashierMember c;
            MenuSideProduct msp;
            RawMainProduct rmp;
            FurnitureFun ff;
            switch(StartUpchoice)
                {
                case 1:
                        system("cls");
                        m.registerme();
                        system("cls");
                        dominozownerswitch();
                    break;
                case 2:
                        system("cls");
                        m.Managerswitch();
                        system("cls");
                        dominozownerswitch();
                    break;
                case 3:
                        system("cls");
                        c.cashierswitch();
                        system("cls");
                        dominozownerswitch();
                    break;
                case 4:
                        system("cls");
                        d.deliveryboyswitch();
                        system("cls");
                        dominozownerswitch();
                    break;
                case 5:
                        system("cls");
                        msp.menuproductswitch();
                        system("cls");
                        dominozownerswitch();
                    break;
                case 6:
                        system("cls");
                        rmp.rawproductswitch();
                        system("cls");
                        dominozownerswitch();
                    break;
                case 7:
                        system("cls");
                        ff.furnitureswitch();
                        system("cls");
                        dominozownerswitch();
                    break;
                case 8:
                        return 0;
                    break;
                default:
                        system("cls");
                        cout<<" **Wrong Choice";
                        dominozownerswitch();
            }

        }

        int dominozgetmanagerchoice()
        {
            cout<<"\n\n\t\t\t------------------------------";
            cout<<"\n\t\t\t         Manager Main System   ";
            cout<<"\n\t\t\t------------------------------";
            cout<<"\n\n\t\t\t What you want to do?\n";
            cout<<"\n\t\t\t1.\t Manager System\n\t\t\t2.\t Cashier System \n\t\t\t3.\t Delivery Boy System \n\t\t\t4.\t Menu Side Product System \n \t\t\t5.\t Raw Product System \n \t\t\t6.\t Furniture System \n \t\t\t7.\t Log Out \n";
            cout<<"\n\nEnter Your Roll Option: ";
            cin >> StartUpchoice;

            while(!cin.good())
            {
                cout<<"**Please Enter Number Values Only \n";
                cin.clear();
                cin.ignore(2000000,'\n');
                cout<<"\n\n\t\t\t------------------------------";
                cout<<"\n\t\t\t         Manager Main System   ";
                cout<<"\n\t\t\t------------------------------";
                cout<<"\n\n\t\t\t What you want to do?\n";
                cout<<"\n\t\t\t1.\t Manager System\n\t\t\t2.\t Cashier System \n\t\t\t3.\t Delivery Boy System \n\t\t\t4.\t Menu Side Product System \n \t\t\t5.\t Raw Product System \n \t\t\t6.\t Furniture System \n \t\t\t7.\t Log Out \n";
                cout<<"\n\nEnter Your Roll Option: ";
                cin >> StartUpchoice;
            }
            return StartUpchoice;
        }

        int dominozmanagerswitch()
        {
            system("color f0");

            StartUpchoice=dominozgetmanagerchoice();
            ManagerDetails m;
            DeliveryBoy1 d;
            CashierMember c;
            MenuSideProduct msp;
            RawMainProduct rmp;
            FurnitureFun ff;
            switch(StartUpchoice)
                {
                case 1:
                        system("cls");
                        m.Managerswitch();
                        system("cls");
                        dominozmanagerswitch();
                    break;
                case 2:
                        system("cls");
                        c.cashierswitch();
                        system("cls");
                        dominozmanagerswitch();
                    break;
                case 3:
                        system("cls");
                        d.deliveryboyswitch();
                        system("cls");
                        dominozmanagerswitch();
                    break;
                case 4:
                        system("cls");
                        msp.menuproductswitch();
                        system("cls");
                        dominozmanagerswitch();
                    break;
                case 5:
                        system("cls");
                        rmp.rawproductswitch();
                        system("cls");
                        dominozmanagerswitch();
                    break;
                case 6:
                        system("cls");
                        ff.furnitureswitch();
                        system("cls");
                        dominozmanagerswitch();
                    break;
                case 7:
                        return 0;
                    break;
                default:
                        system("cls");
                        cout<<" **Wrong Choice";
                        dominozownerswitch();
            }

        }

        int rollgetchoice()
        {
                cout<<"\n\n\t\t\t------------------------------";
                cout<<"\n\t\t\t          LogIn System   ";
                cout<<"\n\t\t\t------------------------------";
                cout<<"\n\n\t\t\t What you want to do?\n";
                cout<<"\n\t\t\t1.\t Owner Of Dominoz \n\t\t\t2.\t Manager Of Dominoz \n\t\t\t3.\t Cashier Of Dominoz \n\t\t\t4.\t Exit \n";
                cout<<"\n\nEnter Your Roll Option: ";
                cin >> StartUpchoice;

                while(!cin.good())
                {
                    cout<<"**Please Enter Number Values Only \n";
                    cin.clear();
                    cin.ignore(2000000,'\n');
                    cout<<"\n\n\t\t\t------------------------------";
                    cout<<"\n\t\t\t          LogIn System   ";
                    cout<<"\n\t\t\t------------------------------";
                    cout<<"\n\n\t\t\t What you want to do?\n";
                    cout<<"\n\t\t\t1.\t Owner Of Dominoz \n\t\t\t2.\t Manager Of Dominoz \n\t\t\t3.\t Cashier Of Dominoz \n\t\t\t4.\t Exit \n";
                    cout<<"\n\nEnter Your Roll Option: ";
                    cin >> StartUpchoice;
                }
                return StartUpchoice;
        }

        public:
        int SatrtUp()
            {
                system("cls");
                StartUpchoice=0;
                StartUpchoice=rollgetchoice();
                ManagerDetails m;
                CashierMember c;
                pizzaorder po;
                switch(StartUpchoice)
                    {
                    case 1:
                        roll="Owner";
                        system("cls");
                        if(m.login(roll)==1)
                        {
                            cout<<"OK";
                            system("cls");
                            dominozownerswitch();
                            system("cls");
                            SatrtUp();
                        }
                        system("cls");
                        SatrtUp();
                        break;
                    case 2:
                        roll="Manager";
                        system("cls");
                        if(m.login(roll)==1)
                        {
                            dominozmanagerswitch();
                            system("cls");
                            SatrtUp();
                        }
                        system("cls");
                        SatrtUp();
                        break;
                    case 3:
                        roll="Cashier";
                        system("cls");
                        cout<<"\n1";

                        string u=c.CashierLogin();
                        //cout<<"\n2u="<<u;
                        if(u=="00")
                        {
                            cout<<"\n3";
                            //cin>>u;
                            //system("cls");
                            SatrtUp();
                        }
                        else
                        {
                            //cin>>u;
                            system("cls");
                            cout<<"\n2";
                            po.orderswitch(u);
                            SatrtUp();
                        }
                        SatrtUp();
                        break;
                    //case 4:
                      //  return 1;
                    //default:
                      //     system("cls");
                        //    cout<<" **Wrong Choice";
                          //  SatrtUp();
                }
        }
};


int main()
{

    //system("cls");
    // administratorPowerPolicy admin;

    //admin.mainmenu();
    //admin.ff();

    // DeliveryBoy1 d;
    // d.deliveryboyswitch();

    // CashierMember p;
   //  p.cashierswitch();

   //  ManagerDetails m;
   //  m.Managerswitch();

   // FurnitureFun f;
   // f.furnitureswitch();

   // CustomerDetailsData cdd;
   // cdd.mainmenu();

    //RawMainProduct RMP;
    //RMP.rawproductswitch();

  // MenuSideProduct msp;
  // msp.menuproductswitch();

   //MenuPizza mp;

   //mp.AddPizzaProduct();

   //mp.getpizzaproductswitch();



    Dominoz d;
    d.SatrtUp();



        //startup s;
        //s.LoadLogo();  // Rohanqqqqq ///Rohanqqqqqsssss

        //system("cls");
       // MenuPizza m;
       // m.getpizzaproductswitch();



       // pizzaorder po;
      //  po.orderswitch();

       // discount d;
       // d.discountswitch();


        //s.backuploader();

       // pizzamenue p;
       // p.ViewPizza();
       // p.AddPizza();
       // p.ViewPizza();

    return 0;
    }




