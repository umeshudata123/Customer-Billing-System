#include "Furniture.h"

void Furniture::addfurniture() {

}

void Furniture::deletefurniture() {

}

void Furniture::updatefurniture(char *furnitureproduct) {

}

void Furniture::viewfurniture() {

}

void Furniture::searchfurniture(char *furniture_name,char *furniture_type) {

}
